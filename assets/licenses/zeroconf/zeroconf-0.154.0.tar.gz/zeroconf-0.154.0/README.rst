python-zeroconf
===============

.. image:: https://github.com/python-zeroconf/python-zeroconf/workflows/CI/badge.svg
   :target: https://github.com/python-zeroconf/python-zeroconf?query=workflow%3ACI+branch%3Amaster

.. image:: https://img.shields.io/pypi/v/zeroconf.svg
    :target: https://pypi.python.org/pypi/zeroconf

.. image:: https://codecov.io/gh/python-zeroconf/python-zeroconf/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/python-zeroconf/python-zeroconf

.. image:: https://img.shields.io/endpoint?url=https://codspeed.io/badge.json
   :target: https://codspeed.io/python-zeroconf/python-zeroconf
   :alt: Codspeed.io status for python-zeroconf

.. image:: https://readthedocs.org/projects/python-zeroconf/badge/?version=latest
    :target: https://python-zeroconf.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status

`Documentation <https://python-zeroconf.readthedocs.io/en/latest/>`_.

This project is a fork of pyzeroconf, originally by Paul Scott-Murphy
(https://github.com/paulsm/pyzeroconf), modified by William McBrine
(https://github.com/wmcbrine/pyzeroconf).

Compatible with:

* Bonjour
* Avahi

Compared to some other Zeroconf/Bonjour/Avahi Python packages, python-zeroconf:

* isn't tied to Bonjour or Avahi
* doesn't use D-Bus
* doesn't force you to use particular event loop or Twisted (asyncio is used under the hood but not required)
* is pip-installable
* has PyPI distribution
* has an optional cython extension for performance (pure python is supported as well)

Python compatibility
--------------------

* CPython 3.11+
* PyPy 3.11+

Versioning
----------

This project uses semantic versioning.

Status
------

This project is actively maintained.

Traffic Reduction
-----------------

Before version 0.32, most traffic reduction techniques described in https://datatracker.ietf.org/doc/html/rfc6762#section-7
where not implemented which could lead to excessive network traffic.  It is highly recommended that version 0.32 or later
is used if this is a concern.

IPv6 support
------------

IPv6 support is relatively new and currently limited, specifically:

* `InterfaceChoice.All` is an alias for `InterfaceChoice.Default` on non-POSIX
  systems.
* Dual-stack IPv6 sockets are used, which may not be supported everywhere (some
  BSD variants do not have them).
* Listening on localhost (`::1`) does not work. Help with understanding why is
  appreciated.

How to get python-zeroconf?
===========================

* PyPI page https://pypi.org/project/zeroconf/
* GitHub project https://github.com/python-zeroconf/python-zeroconf

The easiest way to install python-zeroconf is using pip::

    pip install zeroconf



How do I use it?
================

Here's how to discover services:

.. code-block:: python

    from zeroconf import ServiceBrowser, ServiceListener, Zeroconf


    class EventLogger(ServiceListener):
        def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
            info = zc.get_service_info(type_, name)
            print(f"discovered {name}: {info}")

        def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
            print(f"lost {name}")

        def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
            print(f"refreshed {name}")


    with Zeroconf() as zc:
        ServiceBrowser(zc, "_http._tcp.local.", EventLogger())
        input("browsing, press enter to stop\n")

.. note::

    Discovery and service registration use *all* available network interfaces by default.
    If you want to customize that you need to specify ``interfaces`` argument when
    constructing ``Zeroconf`` object (see the code for details).

To see which service types are present on the network, try:

.. code-block:: python

    from zeroconf import ZeroconfServiceTypes
    print('\n'.join(ZeroconfServiceTypes.find()))

See examples directory for more.

Changelog
=========

`Changelog <CHANGELOG.md>`_

License
=======

GNU Lesser General Public License v2.1 or later (LGPL-2.1-or-later).

The full text of LGPL 2.1 is included in the `COPYING <COPYING>`_ file.
You may, at your option, use this library under the terms of any later
version of the LGPL published by the Free Software Foundation. The
canonical SPDX identifier for this project is ``LGPL-2.1-or-later``, as
declared in ``pyproject.toml``.
